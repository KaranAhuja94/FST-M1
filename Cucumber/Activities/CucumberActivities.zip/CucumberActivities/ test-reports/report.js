$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1_1.feature");
formatter.feature({
  "line": 2,
  "name": "\"First Test\"",
  "description": "",
  "id": "\"first-test\"",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity1_1"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Opening a web page using selenium",
  "description": "",
  "id": "\"first-test\";opening-a-web-page-using-selenium",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on Google Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User types in Cheese and hits ENTER",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Show how many search results were shown",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close the browser",
  "keyword": "And "
});
formatter.match({
  "location": "GoogleSearchSteps.setUp()"
});
formatter.result({
  "duration": 4659974400,
  "status": "passed"
});
formatter.match({
  "location": "GoogleSearchSteps.search()"
});
formatter.result({
  "duration": 97984700,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "GoogleSearchSteps.close()"
});
formatter.result({
  "status": "skipped"
});
formatter.uri("Activity1_3.feature");
formatter.feature({
  "line": 2,
  "name": "Testing with Tags",
  "description": "I want to use this template for my feature file",
  "id": "testing-with-tags",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity1_3"
    }
  ]
});
formatter.scenario({
  "line": 6,
  "name": "Testing with Simple Alert",
  "description": "",
  "id": "testing-with-tags;testing-with-simple-alert",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@SimpleAlert"
    },
    {
      "line": 5,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is on the page",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User clicks the Simple Alert button",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Alert Opens",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Read the text from it and print it",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Close the alert",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Read the result text",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "PromptDemo.setUp()"
});
formatter.result({
  "duration": 3982605700,
  "status": "passed"
});
formatter.match({
  "location": "PromptDemo.simpleAlert()"
});
formatter.result({
  "duration": 98325100,
  "status": "passed"
});
formatter.match({
  "location": "PromptDemo.switchToAlert()"
});
formatter.result({
  "duration": 4507900,
  "status": "passed"
});
formatter.match({
  "location": "PromptDemo.readTextAndPrint()"
});
formatter.result({
  "duration": 5301000,
  "status": "passed"
});
formatter.match({
  "location": "PromptDemo.closeAlert()"
});
formatter.result({
  "duration": 34179100,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});